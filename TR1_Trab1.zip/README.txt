Trabalho 1 de Teleinformática e Redes 1
Pedro Nogueira - 14/0065032
Gabriel Moretto - 15/0154917
Diogo Sampaio - 16/0056489
UnB - 2020/2

Repositório: https://github.com/bananahell/trabalhoTR1
README.md no repositório contém instruções de execução e explicações do projeto.
Este zip contém o relatório na pasta raiz e o código fonte na pasta fonte.
Rode o comando "make ajuda" na pasta fonte para receber instruções.
