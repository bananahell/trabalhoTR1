#include "camadaAplicacao.h"

int main() {
  AplicacaoTransmissora();
  return 0;
}
